# 01 · Opening Page — `hello` → `MEET WITH DEVELOPER` → White Flash

This is **part one** of your portfolio. It is a full black screen, like a MacBook first start.

**Timeline**

| Time | What happens |
|---|---|
| 0.0 s | Pure black screen |
| 0.5 – 3.0 s | `hello` is written in handwriting style (pen line draws, then fills white with a soft glow) |
| 3.2 s | Next row types **MEET WITH DEVELOPER** in white capitals, with a blinking cursor |
| after typing | **White flash** → screen collapses like an old system turning off (white → thin line → dot) |
| ~1.5 s later | Your portfolio is open (with a light bloom fading in) |

Visitors can press `Enter`, `Space`, `Esc` or click **SKIP** at any time. If the visitor has "reduce motion" on, the intro is skipped automatically.

Files in this part: `IntroHello.tsx`, `IntroHello.css`, `App.tsx`, `main.tsx`, a small change in `index.html`.

---

## 1. `src/components/IntroHello.tsx`

```tsx
import { useEffect, useRef, useState } from 'react'
import { motion } from 'motion/react'
import './IntroHello.css'

// Change the words here
const GREETING = 'hello'
const TAGLINE = 'MEET WITH DEVELOPER'
const TYPE_MS = 75 // typing speed (milliseconds per letter)
const TAGLINE_AT = 3200 // when the second row starts

type Props = { onReveal: () => void; onDone: () => void }

export default function IntroHello({ onReveal, onDone }: Props) {
  const [fontReady, setFontReady] = useState(false)
  const [typed, setTyped] = useState('')
  const [tagline, setTagline] = useState(false)
  const [flash, setFlash] = useState(false)
  const [black, setBlack] = useState(true)

  const timers = useRef<number[]>([])
  const flashed = useRef(false)
  const done = useRef(false)

  const later = (fn: () => void, ms: number) => {
    timers.current.push(window.setTimeout(fn, ms))
  }
  const clear = () => {
    timers.current.forEach(window.clearTimeout)
    timers.current = []
  }
  const finish = () => {
    if (done.current) return
    done.current = true
    onDone()
  }

  // White flash, then portfolio is mounted under it, then flash collapses
  const startFlash = () => {
    if (flashed.current) return
    flashed.current = true
    clear()
    setFlash(true)
    later(() => {
      setBlack(false)
      onReveal()
    }, 170)
    later(finish, 1500)
  }

  // Skip animation for people who prefer reduced motion
  useEffect(() => {
    if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
      onReveal()
      finish()
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  // Wait for the handwriting font, so the writing starts clean
  useEffect(() => {
    let live = true
    document.fonts
      .load('200px "Great Vibes"', GREETING)
      .catch(() => {})
      .finally(() => {
        if (live) setFontReady(true)
      })
    return () => {
      live = false
    }
  }, [])

  // Timeline
  useEffect(() => {
    if (!fontReady) return
    later(() => setTagline(true), TAGLINE_AT)
    later(startFlash, TAGLINE_AT + TAGLINE.length * TYPE_MS + 1000)
    return clear
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [fontReady])

  // Typing effect
  useEffect(() => {
    if (!tagline) return
    let i = 0
    const id = window.setInterval(() => {
      i += 1
      setTyped(TAGLINE.slice(0, i))
      if (i >= TAGLINE.length) window.clearInterval(id)
    }, TYPE_MS)
    return () => window.clearInterval(id)
  }, [tagline])

  // Keyboard skip
  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Enter' || e.key === ' ' || e.key === 'Escape') startFlash()
    }
    window.addEventListener('keydown', onKey)
    return () => window.removeEventListener('keydown', onKey)
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [])

  return (
    <>
      {black && (
        <div className="intro-root" role="dialog" aria-label="Portfolio intro">
          <span className="intro-hud" style={{ top: '1.25rem', left: '1.25rem' }}>
            PORTFOLIO · V1.0
          </span>
          <span className="intro-hud" style={{ top: '1.25rem', right: '1.25rem' }}>
            ● REC
          </span>

          <div className="intro-stack">
            {fontReady && (
              <svg className="hello-svg" viewBox="0 0 1000 340" role="img" aria-label={GREETING}>
                <defs>
                  <linearGradient id="wipeGrad" x1="0" x2="1" y1="0" y2="0">
                    <stop offset="0" stopColor="#fff" />
                    <stop offset="0.9" stopColor="#fff" />
                    <stop offset="1" stopColor="#000" />
                  </linearGradient>
                  <mask id="wipeMask" maskUnits="userSpaceOnUse" x="0" y="0" width="1000" height="340">
                    <rect className="hello-wipe" x="0" y="0" width="1000" height="340" fill="url(#wipeGrad)" />
                  </mask>
                </defs>
                <g mask="url(#wipeMask)">
                  <text className="hello-glyphs" x="500" y="250" textAnchor="middle">
                    {GREETING}
                  </text>
                </g>
              </svg>
            )}
            <p className="intro-tagline" aria-live="polite">
              {typed}
              {tagline && <span className="intro-caret" />}
            </p>
          </div>

          <button className="intro-skip" onClick={startFlash}>
            SKIP ↵
          </button>
        </div>
      )}

      {flash && (
        <motion.div
          className="flash-layer"
          initial={{ opacity: 0, scaleX: 1, scaleY: 1 }}
          animate={{
            opacity: [0, 1, 1, 1, 1, 0],
            scaleY: [1, 1, 1, 0.012, 0.012, 0],
            scaleX: [1, 1, 1, 1, 0, 0]
          }}
          transition={{ duration: 1.4, times: [0, 0.1, 0.32, 0.68, 0.88, 1], ease: 'easeInOut' }}
        />
      )}
    </>
  )
}
```

---

## 2. `src/components/IntroHello.css`

```css
.intro-root {
  position: fixed;
  inset: 0;
  z-index: 50;
  display: grid;
  place-items: center;
  overflow: hidden;
  background: #000;
}

.intro-stack {
  display: flex;
  flex-direction: column;
  align-items: center;
  gap: 1.2rem;
  padding: 0 1rem;
}

.hello-svg {
  width: min(86vw, 760px);
  height: auto;
  overflow: visible;
}

/* Handwriting: the pen outline draws, the mask wipes left→right, then it fills white */
.hello-glyphs {
  font-family: 'Great Vibes', cursive;
  font-size: 270px;
  fill: transparent;
  stroke: #fff;
  stroke-width: 2.2;
  stroke-linejoin: round;
  stroke-linecap: round;
  stroke-dasharray: 2200;
  stroke-dashoffset: 2200;
  animation:
    hello-draw 2.4s 0.5s cubic-bezier(0.55, 0.05, 0.25, 1) forwards,
    hello-fill 0.9s 2.5s ease forwards;
}
@keyframes hello-draw {
  to { stroke-dashoffset: 0; }
}
@keyframes hello-fill {
  to {
    fill: #fff;
    stroke-width: 0;
    filter: drop-shadow(0 0 16px rgba(255, 255, 255, 0.5));
  }
}

.hello-wipe {
  transform-box: fill-box;
  transform-origin: 0 50%;
  transform: scaleX(0);
  animation: hello-wipe 2.5s 0.5s cubic-bezier(0.45, 0.05, 0.3, 1) forwards;
}
@keyframes hello-wipe {
  to { transform: scaleX(1.06); }
}

/* Second row */
.intro-tagline {
  min-height: 1.6em;
  margin: 0;
  font-family: 'JetBrains Mono', ui-monospace, monospace;
  font-weight: 500;
  font-size: clamp(0.7rem, 2.2vw, 1.15rem);
  letter-spacing: 0.5em;
  text-transform: uppercase;
  white-space: nowrap;
  color: #fff;
}
.intro-caret {
  display: inline-block;
  width: 0.55em;
  height: 1.05em;
  margin-left: 0.2em;
  vertical-align: -0.15em;
  background: #fff;
  animation: intro-caret 1s steps(1) infinite;
}
@keyframes intro-caret {
  50% { opacity: 0; }
}

/* Small corner labels (movie HUD look) */
.intro-hud {
  position: absolute;
  font: 500 10px/1 'JetBrains Mono', ui-monospace, monospace;
  letter-spacing: 0.25em;
  color: rgba(255, 255, 255, 0.35);
}

.intro-skip {
  position: absolute;
  right: 1.25rem;
  bottom: 1.25rem;
  padding: 0.5rem 0.9rem;
  border: 1px solid rgba(255, 255, 255, 0.25);
  border-radius: 999px;
  background: transparent;
  color: rgba(255, 255, 255, 0.7);
  font: 500 10px/1 'JetBrains Mono', ui-monospace, monospace;
  letter-spacing: 0.25em;
  cursor: pointer;
  transition: 0.2s;
}
.intro-skip:hover {
  background: #fff;
  color: #000;
}

/* White flash that collapses like a system turning off */
.flash-layer {
  position: fixed;
  inset: 0;
  z-index: 60;
  background: #fff;
  box-shadow: 0 0 80px 20px #fff;
  transform-origin: 50% 50%;
  pointer-events: none;
}
```

---

## 3. `src/App.tsx`

```tsx
import { useState } from 'react'
import { BrowserRouter } from 'react-router-dom'
import { SettingsProvider } from './lib/settings'
import { AuthProvider } from './lib/auth'
import { ProfileProvider } from './lib/profile'
import IntroHello from './components/IntroHello'
import AppShell from './components/AppShell'

const KEY = 'intro-seen'

export default function App() {
  const seen = sessionStorage.getItem(KEY) === '1'
  const [revealed, setRevealed] = useState(seen) // portfolio is mounted
  const [introOn, setIntroOn] = useState(!seen) // intro is mounted

  return (
    <SettingsProvider>
      <AuthProvider>
        <ProfileProvider>
          <BrowserRouter>
            {revealed && <AppShell />}
            {introOn && (
              <IntroHello
                onReveal={() => setRevealed(true)}
                onDone={() => {
                  sessionStorage.setItem(KEY, '1')
                  setIntroOn(false)
                }}
              />
            )}
          </BrowserRouter>
        </ProfileProvider>
      </AuthProvider>
    </SettingsProvider>
  )
}
```

---

## 4. `src/main.tsx` (replace everything)

```tsx
import { StrictMode } from 'react'
import { createRoot } from 'react-dom/client'
import '@fontsource-variable/inter'
import '@fontsource/great-vibes'
import '@fontsource/jetbrains-mono'
import '@fontsource/jetbrains-mono/500.css'
import './index.css'
import App from './App'

createRoot(document.getElementById('root')!).render(
  <StrictMode>
    <App />
  </StrictMode>
)
```

---

## 5. `index.html` — keep the screen black while loading

Inside `<head>` set the title and theme colour, and make the body black:

```html
<title>Developer Portfolio</title>
<meta name="theme-color" content="#000000" />
<style>html,body{background:#000}</style>
```

---

## 6. Change the look

| Want to change | Edit |
|---|---|
| Words | `GREETING`, `TAGLINE` at the top of `IntroHello.tsx` |
| Typing speed | `TYPE_MS` |
| Another handwriting font | `npm i @fontsource/caveat`, import it in `main.tsx`, change `'Great Vibes'` in the `.tsx` (font load line) and in the `.css` |
| Slower or faster writing | the `2.4s` / `2.5s` numbers in `.hello-glyphs` and `.hello-wipe` |
| Flash length | `duration: 1.4` and the `later(finish, 1500)` line |
| Show intro every time | in `App.tsx` change `sessionStorage` to a variable that is always `false` |

> This file needs `02-foundation-layout-dock.md` to run (the `AppShell`, `lib/settings`, `lib/auth`, `lib/profile` files). Create those next.
