# 04 · Menu 2 — My Projects

Each project is a **folder** (your `FolderFloat` component). Hover the folder (tap on phone) and your project highlights float out as pills. Click a pill or **Details** to open the full project.

The owner can **add, edit and delete** projects. Highlights and tags are typed with commas.

**Route:** `/projects` · **Vendor file:** `src/vendor/FolderFloat.jsx` + `FolderFloat.css` (optional, fallback included).

---

## `src/pages/Projects.tsx`

```tsx
import { useState, type ChangeEvent, type FormEvent } from 'react'
import { ArrowUpRight, Pencil, Plus, Trash2 } from 'lucide-react'
import { EmptyState, Modal, PageHeader } from '../components/ui'
import { OwnerOnly } from '../lib/auth'
import { useCollection } from '../lib/useCollection'
import { useIsMobile } from '../lib/useIsMobile'
import { vendor } from '../lib/vendor'
import type { Project } from '../lib/types'

type Draft = Omit<Project, 'id'>
const split = (s: string) => s.split(',').map((x) => x.trim()).filter(Boolean)

/* shown until src/vendor/FolderFloat.jsx exists */
function FallbackFolder({ label, sublabel, items, onSelect }: {
  label: string; sublabel: string; items: string[]; onSelect: () => void
}) {
  return (
    <div className="card w-56 p-4 text-center">
      <p className="font-semibold">{label}</p>
      <p className="text-xs text-white/50">{sublabel}</p>
      <div className="mt-3 flex flex-wrap justify-center gap-1.5">
        {items.map((i) => (
          <button key={i} className="chip" onClick={onSelect}>{i}</button>
        ))}
      </div>
    </div>
  )
}

function ProjectForm({ initial, onSave }: { initial?: Project; onSave: (d: Draft) => Promise<void> }) {
  const [f, setF] = useState({
    title: initial?.title ?? '',
    subtitle: initial?.subtitle ?? '',
    description: initial?.description ?? '',
    status: initial?.status ?? '',
    link: initial?.link ?? '',
    highlights: (initial?.highlights ?? []).join(', '),
    tags: (initial?.tags ?? []).join(', ')
  })
  const [busy, setBusy] = useState(false)
  const set = (k: keyof typeof f) => (e: ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) =>
    setF({ ...f, [k]: e.target.value })

  const submit = async (e: FormEvent) => {
    e.preventDefault()
    setBusy(true)
    await onSave({
      title: f.title.trim(), subtitle: f.subtitle.trim(), description: f.description.trim(),
      status: f.status.trim(), link: f.link.trim(), highlights: split(f.highlights), tags: split(f.tags)
    })
    setBusy(false)
  }

  return (
    <form onSubmit={submit} className="space-y-3">
      <div><label className="label">Title</label><input required className="input" value={f.title} onChange={set('title')} /></div>
      <div><label className="label">Subtitle (event / type)</label><input className="input" value={f.subtitle} onChange={set('subtitle')} /></div>
      <div><label className="label">Description</label><textarea rows={3} className="input" value={f.description} onChange={set('description')} /></div>
      <div><label className="label">Highlights (short, comma separated — these float out of the folder)</label><input className="input" value={f.highlights} onChange={set('highlights')} /></div>
      <div><label className="label">Tags (comma separated)</label><input className="input" value={f.tags} onChange={set('tags')} /></div>
      <div className="grid gap-3 sm:grid-cols-2">
        <div><label className="label">Status</label><input className="input" value={f.status} onChange={set('status')} placeholder="In progress" /></div>
        <div><label className="label">Link (GitHub / live)</label><input className="input" value={f.link} onChange={set('link')} placeholder="https://" /></div>
      </div>
      <button className="btn btn-solid" disabled={busy}>{busy ? 'Saving…' : 'Save project'}</button>
    </form>
  )
}

export default function Projects() {
  const { items, loading, add, update, remove } = useCollection<Project>('projects')
  const mobile = useIsMobile()
  const FolderFloat = vendor('FolderFloat')
  const [active, setActive] = useState<Project | null>(null)
  const [editing, setEditing] = useState<Project | 'new' | null>(null)

  const save = async (d: Draft) => {
    if (editing === 'new') await add(d)
    else if (editing) await update(editing.id, d)
    setEditing(null)
    setActive(null)
  }

  return (
    <div>
      <PageHeader index="02 / MY PROJECTS" title="My Projects" sub="Open a folder to see what is inside. Click any pill for full details.">
        <OwnerOnly>
          <button className="btn btn-solid" onClick={() => setEditing('new')}><Plus size={16} /> Add project</button>
        </OwnerOnly>
      </PageHeader>

      {!loading && items.length === 0 && (
        <EmptyState title="No projects yet" text="Login in Settings, then press Add project." />
      )}

      <div className="grid gap-x-8 gap-y-10 sm:grid-cols-2 lg:grid-cols-3">
        {items.map((p) => {
          const pills = p.highlights.length ? p.highlights : ['Details']
          return (
            <div key={p.id} className="flex flex-col items-center gap-4 pt-28">
              {FolderFloat ? (
                <FolderFloat
                  items={pills} label={p.title} sublabel={p.subtitle}
                  trigger={mobile ? 'click' : 'hover'} closeOnSelect physics drift={0.5}
                  onSelect={() => setActive(p)}
                  folderColor="#27272a" frontColor="#3f3f46" paperColor="#fafafa"
                  itemColor="#fafafa" itemTextColor="#09090b" labelColor="#fafafa"
                  width={200} height={148} radius={14} spread={180} lift={26} tilt={8}
                  flapAngle={34} restAngle={16} openDuration={520} stagger={45} bounce={0.3}
                />
              ) : (
                <FallbackFolder label={p.title} sublabel={p.subtitle} items={pills} onSelect={() => setActive(p)} />
              )}
              <button className="btn" onClick={() => setActive(p)}>Details</button>
            </div>
          )
        })}
      </div>

      {/* details */}
      <Modal open={!!active && !editing} onClose={() => setActive(null)} title={active?.title ?? ''} wide>
        {active && (
          <div className="space-y-4">
            <div className="flex flex-wrap items-center gap-2">
              <span className="chip">{active.subtitle}</span>
              {active.status && <span className="chip">● {active.status}</span>}
            </div>
            <p className="leading-relaxed text-white/75">{active.description}</p>
            <div className="flex flex-wrap gap-2">
              {[...active.highlights, ...active.tags].map((t) => <span key={t} className="chip">{t}</span>)}
            </div>
            <div className="flex flex-wrap gap-2 pt-2">
              {active.link && (
                <a className="btn btn-solid" href={active.link} target="_blank" rel="noreferrer">
                  Open project <ArrowUpRight size={16} />
                </a>
              )}
              <OwnerOnly>
                <button className="btn" onClick={() => setEditing(active)}><Pencil size={14} /> Edit</button>
                <button
                  className="btn"
                  onClick={async () => {
                    if (confirm(`Delete "${active.title}"?`)) {
                      await remove(active.id)
                      setActive(null)
                    }
                  }}
                >
                  <Trash2 size={14} /> Delete
                </button>
              </OwnerOnly>
            </div>
          </div>
        )}
      </Modal>

      {/* add / edit */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing === 'new' ? 'Add project' : 'Edit project'} wide>
        {editing && <ProjectForm initial={editing === 'new' ? undefined : editing} onSave={save} />}
      </Modal>
    </div>
  )
}
```

---

## Notes

- Keep each highlight to **2–4 words** so the pills do not overlap.
- Phones have no hover, so the folder opens with a tap (`trigger="click"` is set automatically).
- Colours are black / grey / white to match the theme. Change `folderColor`, `frontColor` etc. if you like.
- More projects = just press **Add project**. No code change needed.
