# 00 · START HERE — Setup for your Black & White Portfolio

Modern stack: **React + TypeScript + Vite + Tailwind CSS + Motion** (frontend) and **Node + Express** (backend).
No plain HTML / CSS / JS files. Everything is black and white, with film-grain, light-leak and flash effects.

Follow the md files **in number order**. Each menu has its own file.

---

## 1. What you will get

| Part | File |
|---|---|
| Opening page (hello → MEET WITH DEVELOPER → white flash) | `01-intro-hello-opening.md` |
| Shared code, layout, Dock menu, black & white theme | `02-foundation-layout-dock.md` |
| Menu 1 Dashboard | `03-menu-dashboard.md` |
| Menu 2 My Projects (folder component) | `04-menu-my-projects.md` |
| Menu 3 AI Tools | `05-menu-ai-tools.md` |
| Menu 4 Certificates (many courses, DriftWall) | `06-menu-certificates.md` |
| Menu 5 Photo Booth (many photos, 3D sphere) | `07-menu-photo-booth.md` |
| Menu 6 Analytics (real page views) | `08-menu-analytics.md` |
| Menu 7 Skills | `09-menu-skills.md` |
| Menu 8 Documentation | `10-menu-documentation.md` |
| Menu 9 Profile (change photo + details) | `11-menu-profile.md` |
| Menu 10 Contact | `12-menu-contact.md` |
| Menu 11 Settings + 12 Logout | `13-menu-settings-logout.md` |
| Backend (login, uploads, database, analytics) | `14-backend-server.md` |
| End-of-page TechText effect | `15-footer-techtext-effect.md` |

Menu order in the Dock: Dashboard, My Projects, AI Tools, Certificates, Photo Booth, Analytics, Skills, Documentation, Profile, Contact, Settings, Logout.
(Certificates, Photo Booth and Skills are the extra pages a developer portfolio needs.)

---

## 2. How I understood your idea

- **Opening page:** full black screen. The word `hello` is written in a handwriting style (like the MacBook welcome screen). Next row types `MEET WITH DEVELOPER` in white capital letters. Then a **white flash** and the screen **turns off like an old system** (white collapses into a line, then a dot) and the portfolio opens.
- **Portfolio:** not a normal top menu. Navigation is a **macOS-style Dock** at the bottom.
- **You can change everything:** log in as owner, then change profile photo and details, upload many certificates and many photos, add projects, edit documentation.
- **No fake text:** all sample text uses your own words (CropShield AI, TIME CART, Smart India Hackathon, Python, React). You can edit all of it from the website.
- **If you wanted something different** (for example a different flash style), tell me and I will change only that file.

---

## 3. Install on your MacBook

1. Install **Node.js 20.19 or newer** (22 LTS is best). Using Homebrew:
   ```bash
   brew install node
   node -v
   ```
   If you do not have Homebrew, download Node from nodejs.org.
2. Install **VS Code** from code.visualstudio.com.
3. In VS Code press `Cmd + Shift + P`, type `Shell Command: Install 'code' command in PATH`, press Enter.

---

## 4. VS Code extensions to install

Press `Cmd + Shift + X`, search the name, click Install. Or run all at once in Terminal:

```bash
code --install-extension dsznajder.es7-react-js-snippets
code --install-extension bradlc.vscode-tailwindcss
code --install-extension esbenp.prettier-vscode
code --install-extension dbaeumer.vscode-eslint
code --install-extension usernamehw.errorlens
code --install-extension formulahendry.auto-rename-tag
code --install-extension christian-kohler.path-intellisense
code --install-extension rangav.vscode-thunder-client
code --install-extension PKief.material-icon-theme
```

| Extension | Why you need it |
|---|---|
| ES7+ React snippets | type `rafce` + Tab to create a component |
| Tailwind CSS IntelliSense | auto-complete for all `className="..."` |
| Prettier | auto-format code (`Shift + Option + F`) |
| ESLint | shows mistakes while you type |
| Error Lens | shows the error text on the same line |
| Auto Rename Tag | renames the closing tag too |
| Path Intellisense | auto-complete for file paths |
| Thunder Client | test the backend API inside VS Code |
| Material Icon Theme | clear file icons |

**Tip for reading these md files:** open any `.md` file and press `Cmd + Shift + V` (preview) or `Cmd + K` then `V` (preview on the side).

**Recommended settings:** `Cmd + ,` → search `format on save` → turn it ON. Set Prettier as default formatter.

---

## 5. Create the project

Open Terminal (in VS Code: `` Ctrl + ` ``) and run:

```bash
npm create vite@latest portfolio -- --template react-ts
cd portfolio
code .
```

A new VS Code window opens inside the `portfolio` folder. Open the Terminal there and run:

```bash
npm install

# frontend packages
npm i react-router-dom motion lucide-react recharts react-markdown remark-gfm
npm i tailwindcss @tailwindcss/vite
npm i @fontsource-variable/inter @fontsource/great-vibes @fontsource/jetbrains-mono

# backend packages
npm i express helmet express-rate-limit multer jsonwebtoken bcryptjs dotenv
npm i -D tsx concurrently @types/express @types/multer @types/jsonwebtoken @types/node
```

Now open `package.json` and replace only the `"scripts"` block with:

```json
"scripts": {
  "dev": "concurrently -k -n web,api -c white,gray \"vite\" \"tsx watch server/index.ts\"",
  "build": "tsc -b && vite build",
  "start": "tsx server/index.ts",
  "lint": "eslint .",
  "preview": "vite preview"
},
```

Replace `vite.config.ts` with:

```ts
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import tailwindcss from '@tailwindcss/vite'

export default defineConfig({
  plugins: [react(), tailwindcss()],
  server: {
    proxy: {
      '/api': 'http://localhost:4000',
      '/uploads': 'http://localhost:4000'
    }
  }
})
```

> If your generated file uses `@vitejs/plugin-react-swc`, keep that import and only add `tailwindcss()` and the `server` block.

Delete these files (not needed): `src/App.css`, `src/assets/react.svg`, `public/vite.svg`.

Create `.env` in the project root (same level as `package.json`):

```env
PORT=4000
ADMIN_PASSWORD=choose-a-strong-password-here
JWT_SECRET=paste-a-long-random-text-here
```

Make a random secret on Mac: `openssl rand -hex 32` and paste the result.

Add these lines to `.gitignore` so private data is never uploaded to GitHub:

```text
.env
server/data
server/uploads
```

---

## 6. Final folder structure

```text
portfolio/
├─ .env
├─ package.json
├─ vite.config.ts
├─ index.html
├─ server/
│  ├─ index.ts          (backend routes)
│  ├─ store.ts          (saves data to a JSON file)
│  ├─ seed.ts           (first-time content)
│  ├─ data/db.json      (created automatically)
│  └─ uploads/          (your photos, certificates, resume — automatic)
└─ src/
   ├─ main.tsx
   ├─ App.tsx
   ├─ index.css
   ├─ lib/
   │  ├─ types.ts  api.ts  image.ts  auth.tsx  profile.tsx
   │  ├─ settings.tsx  useCollection.ts  useApi.ts  useIsMobile.ts
   │  ├─ vendor.tsx  nav.ts
   ├─ vendor/          <- YOUR 6 shared components (see section 7)
   ├─ components/
   │  ├─ IntroHello.tsx  IntroHello.css
   │  ├─ AppShell.tsx  TopBar.tsx  Backdrop.tsx  PortfolioDock.tsx
   │  ├─ SiteFooter.tsx  Terminal.tsx  ui.tsx
   └─ pages/
      ├─ Dashboard.tsx  Projects.tsx  AiTools.tsx  Certificates.tsx
      ├─ PhotoBooth.tsx  Analytics.tsx  Skills.tsx  Documentation.tsx
      └─ Profile.tsx  Contact.tsx  Settings.tsx
```

**How to create a file in VS Code:** right-click the folder in the left Explorer → `New File` → type the name (for example `src/lib/api.ts`) → paste the code → `Cmd + S`.

---

## 7. IMPORTANT — your 6 existing components (`src/vendor/`)

Your md files use components that you already have. I only received the **code of two of them** in this chat, so you must copy them yourself. Create the folder `src/vendor/` and copy the files with **exactly these names**:

| Save in `src/vendor/` | Where to get the code |
|---|---|
| `TechText.jsx` + `TechText.css` | `TechText_Portfolio_Integration.md` (sections 2 and 3) |
| `DriftWall.jsx` + `DriftWall.css` | `portfolio_driftwall_setup.md` (sections 3 and 2) |
| `Dock.jsx` + `Dock.css` | your original Dock source (the one you shared when making `portfolio-dock.md`) |
| `ProfileCard.jsx` + `ProfileCard.css` | your original ProfileCard source |
| `InfiniteMenu.jsx` + `InfiniteMenu.css` | your original InfiniteMenu source |
| `FolderFloat.jsx` + `FolderFloat.css` | your original FolderFloat source (your `project-folder.md` says it was missing earlier too) |

**The project still runs without them.** Every page has a simple black-and-white fallback, so you can start now and add the real components one by one. When a file appears in `src/vendor/`, the page switches to it automatically (restart `npm run dev` once).

I use `lucide-react` icons in the Dock instead of Hugeicons. Your Dock accepts any React element as an icon, so nothing else changes.

---

## 8. Run it

```bash
npm run dev
```

- Website: http://localhost:5173
- Backend: http://localhost:4000 (test: http://localhost:4000/api/profile)

First time you see the intro. Press `Enter` or click **SKIP** to jump ahead. The intro plays once per browser session.

**Become the owner:** Dock → **Settings** → type the `ADMIN_PASSWORD` from `.env`. Now Edit / Upload / Delete buttons appear on every page. Visitors never see them.

**Production build:**

```bash
npm run build
npm start        # everything on http://localhost:4000
```

---

## 9. Troubleshooting

| Problem | Fix |
|---|---|
| `Set JWT_SECRET ... in .env` | `.env` is missing or in the wrong folder (must be next to `package.json`) |
| Page is empty / data does not load | backend not running: check the terminal for `api` errors |
| Login says wrong password | restart `npm run dev` after editing `.env` |
| `Cannot find module './vendor/...'` | you do not need it; check file name spelling in `src/vendor/` |
| Tailwind classes do nothing | `@import "tailwindcss";` must be first line of `src/index.css` and `tailwindcss()` in `vite.config.ts` |
| Intro does not show again | it plays once per session; Settings → **Replay intro** |
| Port 4000 busy | change `PORT` in `.env` **and** the two proxy lines in `vite.config.ts` |
