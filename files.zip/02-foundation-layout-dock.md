# 02 · Foundation — Black & White Theme, Shared Code, Layout, Dock Menu

All pages use these files. Create them once.

**Order:** `index.css` → `lib/*` → `components/ui.tsx` → shell components → `PortfolioDock.tsx`.

---

## 1. `src/index.css` (replace everything)

```css
@import 'tailwindcss';

@theme {
  --font-sans: 'Inter Variable', ui-sans-serif, system-ui, sans-serif;
  --font-mono: 'JetBrains Mono', ui-monospace, SFMono-Regular, Menlo, monospace;
}

:root { color-scheme: dark; }
html, body, #root { min-height: 100%; background: #000; color: #fff; }
body { margin: 0; font-family: var(--font-sans); -webkit-font-smoothing: antialiased; }
::selection { background: #fff; color: #000; }
::-webkit-scrollbar { width: 10px; }
::-webkit-scrollbar-track { background: #000; }
::-webkit-scrollbar-thumb { background: #2a2a2a; border-radius: 10px; }

/* ---------- reusable black & white pieces ---------- */
@layer components {
  .card {
    border: 1px solid rgba(255, 255, 255, 0.1);
    background: rgba(255, 255, 255, 0.03);
    border-radius: 1.5rem;
    backdrop-filter: blur(12px);
    transition: border-color 0.3s, background 0.3s;
  }
  .card:hover { border-color: rgba(255, 255, 255, 0.3); background: rgba(255, 255, 255, 0.05); }
  .panel {
    border: 1px solid rgba(255, 255, 255, 0.15);
    background: #0a0a0a;
    border-radius: 1.5rem;
  }
  .btn {
    display: inline-flex; align-items: center; gap: 0.5rem;
    border: 1px solid rgba(255, 255, 255, 0.25); border-radius: 999px;
    padding: 0.6rem 1.1rem; font-size: 0.85rem; color: #fff; background: transparent;
    transition: 0.25s; cursor: pointer;
  }
  .btn:hover { background: #fff; color: #000; }
  .btn:disabled { opacity: 0.5; cursor: wait; }
  .btn-solid { background: #fff; color: #000; border-color: #fff; }
  .btn-solid:hover { background: transparent; color: #fff; }
  .icon-btn {
    display: grid; place-items: center; width: 2.25rem; height: 2.25rem; border-radius: 999px;
    border: 1px solid rgba(255, 255, 255, 0.15); color: #fff; background: transparent;
    cursor: pointer; transition: 0.2s;
  }
  .icon-btn:hover { background: #fff; color: #000; }
  .input {
    width: 100%; border: 1px solid rgba(255, 255, 255, 0.15); background: rgba(255, 255, 255, 0.04);
    border-radius: 0.9rem; padding: 0.7rem 0.9rem; color: #fff; outline: none; transition: border-color 0.2s;
  }
  .input:focus { border-color: #fff; }
  .chip {
    border: 1px solid rgba(255, 255, 255, 0.15); border-radius: 999px; padding: 0.2rem 0.65rem;
    font-size: 0.72rem; color: rgba(255, 255, 255, 0.7); font-family: var(--font-mono);
  }
  .label { display: block; margin-bottom: 0.35rem; font: 500 0.7rem var(--font-mono); letter-spacing: 0.18em; color: rgba(255, 255, 255, 0.45); text-transform: uppercase; }

  /* mouse-follow light on cards */
  .spot::before {
    content: ''; position: absolute; inset: 0; pointer-events: none; opacity: 0; transition: opacity 0.3s;
    background: radial-gradient(340px circle at var(--mx, 50%) var(--my, 50%), rgba(255, 255, 255, 0.16), transparent 60%);
  }
  .spot:hover::before { opacity: 1; }

  /* markdown text (Documentation page) */
  .md h1 { font-size: 1.9rem; font-weight: 600; letter-spacing: -0.02em; margin: 0 0 1rem; }
  .md h2 { font-size: 1.25rem; font-weight: 600; margin: 2rem 0 0.6rem; padding-bottom: 0.4rem; border-bottom: 1px solid rgba(255, 255, 255, 0.1); }
  .md h3 { font-size: 1rem; font-weight: 600; margin: 1.4rem 0 0.4rem; }
  .md p, .md li { color: rgba(255, 255, 255, 0.72); line-height: 1.75; }
  .md ul { list-style: disc; padding-left: 1.3rem; }
  .md ol { list-style: decimal; padding-left: 1.3rem; }
  .md code { font-family: var(--font-mono); font-size: 0.85em; background: rgba(255, 255, 255, 0.08); padding: 0.1rem 0.35rem; border-radius: 0.4rem; }
  .md pre { background: #050505; border: 1px solid rgba(255, 255, 255, 0.12); border-radius: 1rem; padding: 1rem; overflow: auto; margin: 1rem 0; }
  .md pre code { background: none; padding: 0; }
  .md table { width: 100%; border-collapse: collapse; margin: 1rem 0; font-size: 0.9rem; }
  .md th, .md td { border: 1px solid rgba(255, 255, 255, 0.12); padding: 0.5rem 0.7rem; text-align: left; }
  .md a { text-decoration: underline; text-underline-offset: 3px; }
}

/* ---------- movie look: light leak, grid, vignette, film grain ---------- */
.light-leak {
  position: fixed; inset: -20%; z-index: 0; pointer-events: none;
  background:
    radial-gradient(40% 30% at 20% 15%, rgba(255, 255, 255, 0.1), transparent 70%),
    radial-gradient(35% 30% at 85% 80%, rgba(255, 255, 255, 0.07), transparent 70%);
  animation: leak-drift 22s ease-in-out infinite alternate;
}
@keyframes leak-drift { to { transform: translate3d(6%, 4%, 0) scale(1.1); } }

.grid-lines {
  position: fixed; inset: 0; z-index: 0; pointer-events: none;
  background-image:
    linear-gradient(rgba(255, 255, 255, 0.04) 1px, transparent 1px),
    linear-gradient(90deg, rgba(255, 255, 255, 0.04) 1px, transparent 1px);
  background-size: 64px 64px;
  mask-image: radial-gradient(ellipse at 50% 30%, #000 10%, transparent 70%);
}
.vignette {
  position: fixed; inset: 0; z-index: 20; pointer-events: none;
  background: radial-gradient(ellipse at center, transparent 55%, rgba(0, 0, 0, 0.75));
}
.grain {
  position: fixed; inset: -50%; z-index: 21; pointer-events: none; opacity: 0.08;
  background-image: url("data:image/svg+xml;utf8,<svg xmlns='http://www.w3.org/2000/svg' width='160' height='160'><filter id='n'><feTurbulence type='fractalNoise' baseFrequency='.9' numOctaves='2' stitchTiles='stitch'/><feColorMatrix type='saturate' values='0'/></filter><rect width='100%' height='100%' filter='url(%23n)'/></svg>");
  animation: grain 1s steps(6) infinite;
}
@keyframes grain {
  0% { transform: translate(0, 0); } 20% { transform: translate(-4%, 3%); }
  40% { transform: translate(3%, -4%); } 60% { transform: translate(-3%, -2%); }
  80% { transform: translate(4%, 4%); } 100% { transform: translate(0, 0); }
}

/* settings switches */
html[data-grain='off'] .grain { display: none; }
html[data-motion='off'] *, html[data-motion='off'] *::before, html[data-motion='off'] *::after {
  animation-duration: 0.01ms !important; transition-duration: 0.01ms !important;
}
```

---

## 2. Shared code (`src/lib/`)

### `src/lib/types.ts`

```ts
export type Profile = {
  name: string
  title: string
  handle: string
  status: string
  location: string
  bio: string
  email: string
  github: string
  linkedin: string
  avatar: string
  resumeUrl: string
}

export type Project = {
  id: string
  title: string
  subtitle: string
  description: string
  highlights: string[]
  tags: string[]
  status: string
  link?: string
  image?: string
}

export type Certificate = {
  id: string
  title: string
  issuer: string
  date?: string
  image: string
  href?: string
}

export type Photo = { id: string; title: string; description: string; image: string }
export type Skill = { id: string; name: string; group: string; level: number }
export type DocPage = { id: string; title: string; body: string; order: number }
export type Message = { id: string; name: string; email: string; message: string; createdAt: string }
```

### `src/lib/api.ts`

```ts
const TOKEN_KEY = 'portfolio-token'

export const getToken = () => localStorage.getItem(TOKEN_KEY)
export const setToken = (t: string | null) =>
  t ? localStorage.setItem(TOKEN_KEY, t) : localStorage.removeItem(TOKEN_KEY)

export async function api<T = unknown>(path: string, init: RequestInit = {}): Promise<T> {
  const headers = new Headers(init.headers)
  const token = getToken()
  if (token) headers.set('Authorization', `Bearer ${token}`)
  if (init.body && !(init.body instanceof FormData)) headers.set('Content-Type', 'application/json')

  const res = await fetch(`/api${path}`, { ...init, headers })
  if (res.status === 204) return undefined as T
  if (!res.ok) {
    const body = await res.json().catch(() => ({ error: res.statusText }))
    throw new Error(body.error ?? 'Request failed')
  }
  return res.json() as Promise<T>
}

export async function uploadFile(file: File, kind: string): Promise<string> {
  const form = new FormData()
  form.append('file', file)
  const out = await api<{ url: string }>(`/upload?kind=${encodeURIComponent(kind)}`, {
    method: 'POST',
    body: form
  })
  return out.url
}
```

### `src/lib/image.ts` — crops and shrinks photos before upload (fixes photo position)

```ts
/**
 * Cover-crops an image to a ratio (for example 4/5 for the profile card, 1 for the photo sphere)
 * and shrinks it. focusY: 0 = keep the top, 0.5 = centre, 1 = keep the bottom.
 * Without `aspect`, the photo keeps its own shape and is only resized (good for certificates).
 */
export async function prepareImage(file: File, aspect?: number, focusY = 0.5, maxW = 1600): Promise<File> {
  if (!file.type.startsWith('image/') || file.type === 'image/gif') return file

  const bmp = await createImageBitmap(file)
  const ratio = aspect ?? bmp.width / bmp.height
  let sw = bmp.width
  let sh = bmp.height
  if (sw / sh > ratio) {
    sw = Math.round(sh * ratio)
  } else {
    sh = Math.round(sw / ratio)
  }
  const sx = Math.round((bmp.width - sw) / 2)
  const sy = Math.round((bmp.height - sh) * focusY)

  const outW = Math.min(maxW, sw)
  const outH = Math.round(outW / ratio)
  const canvas = document.createElement('canvas')
  canvas.width = outW
  canvas.height = outH
  canvas.getContext('2d')!.drawImage(bmp, sx, sy, sw, sh, 0, 0, outW, outH)

  const blob = await new Promise<Blob | null>((resolve) => canvas.toBlob(resolve, 'image/webp', 0.9))
  if (!blob) return file
  return new File([blob], file.name.replace(/\.\w+$/, '') + '.webp', { type: 'image/webp' })
}
```

### `src/lib/auth.tsx`

```tsx
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { api, getToken, setToken } from './api'

type AuthCtx = { isOwner: boolean; login: (password: string) => Promise<void>; logout: () => void }
const Ctx = createContext<AuthCtx | null>(null)

export function AuthProvider({ children }: { children: ReactNode }) {
  const [isOwner, setOwner] = useState(!!getToken())

  // if the saved token is old or wrong, drop it
  useEffect(() => {
    if (!getToken()) return
    api('/auth/me').catch(() => {
      setToken(null)
      setOwner(false)
    })
  }, [])

  const login = async (password: string) => {
    const { token } = await api<{ token: string }>('/auth/login', {
      method: 'POST',
      body: JSON.stringify({ password })
    })
    setToken(token)
    setOwner(true)
  }
  const logout = () => {
    setToken(null)
    setOwner(false)
  }

  return <Ctx.Provider value={{ isOwner, login, logout }}>{children}</Ctx.Provider>
}

export function useAuth() {
  const ctx = useContext(Ctx)
  if (!ctx) throw new Error('useAuth must be used inside AuthProvider')
  return ctx
}

/** Shows its children only for the logged-in owner */
export function OwnerOnly({ children }: { children: ReactNode }) {
  const { isOwner } = useAuth()
  return isOwner ? <>{children}</> : null
}
```

### `src/lib/profile.tsx`

```tsx
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'
import { api } from './api'
import type { Profile } from './types'

const EMPTY: Profile = {
  name: '', title: '', handle: '', status: 'Online', location: '',
  bio: '', email: '', github: '', linkedin: '', avatar: '', resumeUrl: ''
}

type Ctx = { profile: Profile; save: (patch: Partial<Profile>) => Promise<void> }
const ProfileCtx = createContext<Ctx>({ profile: EMPTY, save: async () => {} })
export const useProfile = () => useContext(ProfileCtx)

export function ProfileProvider({ children }: { children: ReactNode }) {
  const [profile, setProfile] = useState<Profile>(EMPTY)

  useEffect(() => {
    api<Profile>('/profile').then(setProfile).catch(() => {})
  }, [])

  const save = async (patch: Partial<Profile>) => {
    setProfile(await api<Profile>('/profile', { method: 'PUT', body: JSON.stringify(patch) }))
  }

  return <ProfileCtx.Provider value={{ profile, save }}>{children}</ProfileCtx.Provider>
}
```

### `src/lib/settings.tsx`

```tsx
import { createContext, useContext, useEffect, useState, type ReactNode } from 'react'

type S = { grain: boolean; motion: boolean }
const KEY = 'portfolio-settings'
const DEFAULT: S = { grain: true, motion: true }

const Ctx = createContext<{ s: S; set: (p: Partial<S>) => void }>({ s: DEFAULT, set: () => {} })
export const useSettings = () => useContext(Ctx)

export function SettingsProvider({ children }: { children: ReactNode }) {
  const [s, setS] = useState<S>(() => {
    try {
      return { ...DEFAULT, ...JSON.parse(localStorage.getItem(KEY) ?? '{}') }
    } catch {
      return DEFAULT
    }
  })

  useEffect(() => {
    localStorage.setItem(KEY, JSON.stringify(s))
    document.documentElement.dataset.grain = s.grain ? 'on' : 'off'
    document.documentElement.dataset.motion = s.motion ? 'on' : 'off'
  }, [s])

  return <Ctx.Provider value={{ s, set: (p) => setS((old) => ({ ...old, ...p })) }}>{children}</Ctx.Provider>
}
```

### `src/lib/useCollection.ts` — list / add / edit / delete for any collection

```ts
import { useCallback, useEffect, useState } from 'react'
import { api } from './api'

export function useCollection<T extends { id: string }>(name: string) {
  const [items, setItems] = useState<T[]>([])
  const [loading, setLoading] = useState(true)

  const load = useCallback(async () => {
    try {
      setItems(await api<T[]>(`/${name}`))
    } finally {
      setLoading(false)
    }
  }, [name])

  useEffect(() => {
    load()
  }, [load])

  const add = async (data: Omit<T, 'id'>) => {
    const item = await api<T>(`/${name}`, { method: 'POST', body: JSON.stringify(data) })
    setItems((p) => [...p, item])
    return item
  }
  const update = async (id: string, data: Partial<Omit<T, 'id'>>) => {
    const item = await api<T>(`/${name}/${id}`, { method: 'PUT', body: JSON.stringify(data) })
    setItems((p) => p.map((x) => (x.id === id ? item : x)))
    return item
  }
  const remove = async (id: string) => {
    await api(`/${name}/${id}`, { method: 'DELETE' })
    setItems((p) => p.filter((x) => x.id !== id))
  }

  return { items, loading, add, update, remove, reload: load }
}
```

### `src/lib/useApi.ts`

```ts
import { useEffect, useState } from 'react'
import { api } from './api'

export function useApi<T>(path: string) {
  const [data, setData] = useState<T | null>(null)
  useEffect(() => {
    let live = true
    api<T>(path).then((d) => live && setData(d)).catch(() => {})
    return () => {
      live = false
    }
  }, [path])
  return data
}
```

### `src/lib/useIsMobile.ts`

```ts
import { useEffect, useState } from 'react'

export function useIsMobile(max = 900) {
  const query = `(max-width: ${max}px)`
  const [mobile, setMobile] = useState(() => window.matchMedia(query).matches)
  useEffect(() => {
    const mq = window.matchMedia(query)
    const on = () => setMobile(mq.matches)
    mq.addEventListener('change', on)
    return () => mq.removeEventListener('change', on)
  }, [query])
  return mobile
}
```

### `src/lib/vendor.tsx` — loads your 6 components if the file exists

```tsx
import type { ComponentType } from 'react'

type AnyComp = ComponentType<Record<string, unknown>>

// finds src/vendor/*.jsx. If a file is missing, vendor('Name') returns null and the page uses its fallback.
const mods = import.meta.glob<{ default: AnyComp }>('../vendor/*.jsx', { eager: true })

export const vendor = (name: string): AnyComp | null => mods[`../vendor/${name}.jsx`]?.default ?? null
```

### `src/lib/nav.ts` — the menu list (one place)

```ts
import {
  LayoutDashboard, FolderKanban, Sparkles, Award, Camera, BarChart3,
  Layers, BookOpen, UserRound, Mail, Settings, type LucideIcon
} from 'lucide-react'

export type NavItem = { no: string; id: string; path: string; label: string; icon: LucideIcon }

export const NAV: NavItem[] = [
  { no: '01', id: 'dashboard', path: '/', label: 'Dashboard', icon: LayoutDashboard },
  { no: '02', id: 'projects', path: '/projects', label: 'My Projects', icon: FolderKanban },
  { no: '03', id: 'ai-tools', path: '/ai-tools', label: 'AI Tools', icon: Sparkles },
  { no: '04', id: 'certificates', path: '/certificates', label: 'Certificates', icon: Award },
  { no: '05', id: 'photo-booth', path: '/photo-booth', label: 'Photo Booth', icon: Camera },
  { no: '06', id: 'analytics', path: '/analytics', label: 'Analytics', icon: BarChart3 },
  { no: '07', id: 'skills', path: '/skills', label: 'Skills', icon: Layers },
  { no: '08', id: 'docs', path: '/docs', label: 'Documentation', icon: BookOpen },
  { no: '09', id: 'profile', path: '/profile', label: 'Profile', icon: UserRound },
  { no: '10', id: 'contact', path: '/contact', label: 'Contact', icon: Mail },
  { no: '11', id: 'settings', path: '/settings', label: 'Settings', icon: Settings }
]
// 12 Logout is an action (see PortfolioDock.tsx)
```

---

## 3. Shared UI — `src/components/ui.tsx`

```tsx
import { useEffect, useRef, useState, type ReactNode } from 'react'
import { createPortal } from 'react-dom'
import { animate, AnimatePresence, motion, useMotionValue, useSpring } from 'motion/react'
import { Upload, X } from 'lucide-react'
import { uploadFile } from '../lib/api'
import { prepareImage } from '../lib/image'

/* ---------- page title with a wipe reveal ---------- */
export function PageHeader({ index, title, sub, children }: {
  index: string; title: string; sub?: string; children?: ReactNode
}) {
  return (
    <header className="mb-10 flex flex-wrap items-end justify-between gap-4">
      <div>
        <p className="font-mono text-[11px] tracking-[0.3em] text-white/40">{index}</p>
        <motion.h1
          className="mt-2 text-4xl font-semibold tracking-tight md:text-6xl"
          initial={{ clipPath: 'inset(0 100% 0 0)' }}
          animate={{ clipPath: 'inset(0 0% 0 0)' }}
          transition={{ duration: 0.9, ease: [0.2, 0.7, 0.2, 1] }}
        >
          {title}
        </motion.h1>
        {sub && <p className="mt-3 max-w-xl text-white/55">{sub}</p>}
      </div>
      <div className="flex flex-wrap items-center gap-2">{children}</div>
    </header>
  )
}

/* ---------- popup window (rendered on <body>, so it is always centred) ---------- */
export function Modal({ open, onClose, title, children, wide }: {
  open: boolean; onClose: () => void; title: string; children: ReactNode; wide?: boolean
}) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    window.addEventListener('keydown', onKey)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKey)
      document.body.style.overflow = ''
    }
  }, [open, onClose])

  return createPortal(
    <AnimatePresence>
      {open && (
        <motion.div
          className="fixed inset-0 z-[80] grid place-items-center bg-black/80 p-4 backdrop-blur-md"
          initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
          onClick={onClose}
        >
          <motion.div
            role="dialog" aria-modal="true" aria-label={title}
            className={`panel max-h-[88vh] w-full overflow-auto p-6 ${wide ? 'max-w-3xl' : 'max-w-lg'}`}
            initial={{ scale: 0.94, y: 20, opacity: 0 }} animate={{ scale: 1, y: 0, opacity: 1 }}
            exit={{ scale: 0.96, opacity: 0 }} onClick={(e) => e.stopPropagation()}
          >
            <div className="mb-4 flex items-center justify-between gap-4">
              <h3 className="text-lg font-semibold">{title}</h3>
              <button className="icon-btn" onClick={onClose} aria-label="Close"><X size={16} /></button>
            </div>
            {children}
          </motion.div>
        </motion.div>
      )}
    </AnimatePresence>,
    document.body
  )
}

/* ---------- card with a light that follows the mouse (+ optional 3D tilt) ---------- */
export function SpotlightCard({ children, className = '', tilt = 0, onClick }: {
  children: ReactNode; className?: string; tilt?: number; onClick?: () => void
}) {
  const ref = useRef<HTMLDivElement>(null)
  const rx = useMotionValue(0)
  const ry = useMotionValue(0)
  const sx = useSpring(rx, { stiffness: 200, damping: 20 })
  const sy = useSpring(ry, { stiffness: 200, damping: 20 })

  const move = (e: React.MouseEvent) => {
    const el = ref.current
    if (!el) return
    const r = el.getBoundingClientRect()
    const x = e.clientX - r.left
    const y = e.clientY - r.top
    el.style.setProperty('--mx', `${x}px`)
    el.style.setProperty('--my', `${y}px`)
    if (tilt) {
      ry.set((x / r.width - 0.5) * tilt * 2)
      rx.set(-(y / r.height - 0.5) * tilt * 2)
    }
  }
  const leave = () => {
    rx.set(0)
    ry.set(0)
  }

  return (
    <motion.div
      ref={ref} onMouseMove={move} onMouseLeave={leave} onClick={onClick}
      style={{ rotateX: sx, rotateY: sy, transformPerspective: 900 }}
      className={`spot card relative overflow-hidden ${className}`}
    >
      {children}
    </motion.div>
  )
}

/* ---------- file upload button (resizes / crops images before upload) ---------- */
export function UploadButton({ kind, onUploaded, multiple, accept = 'image/*', label = 'Upload', aspect, focusY, className = 'btn' }: {
  kind: string
  onUploaded: (url: string, file: File) => void | Promise<void>
  multiple?: boolean
  accept?: string
  label?: string
  aspect?: number
  focusY?: number
  className?: string
}) {
  const ref = useRef<HTMLInputElement>(null)
  const [busy, setBusy] = useState(false)
  const [error, setError] = useState('')

  const pick = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(e.target.files ?? [])
    e.target.value = ''
    if (!files.length) return
    setBusy(true)
    setError('')
    try {
      for (const file of files) {
        const ready = file.type.startsWith('image/') ? await prepareImage(file, aspect, focusY) : file
        const url = await uploadFile(ready, kind)
        await onUploaded(url, file)
      }
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Upload failed')
    } finally {
      setBusy(false)
    }
  }

  return (
    <>
      <input ref={ref} type="file" hidden multiple={multiple} accept={accept} onChange={pick} />
      <button type="button" className={className} disabled={busy} onClick={() => ref.current?.click()}>
        <Upload size={16} /> {busy ? 'Uploading…' : label}
      </button>
      {error && <span className="text-xs text-white/60">{error}</span>}
    </>
  )
}

/* ---------- number that counts up ---------- */
export function Count({ to }: { to: number }) {
  const [v, setV] = useState(0)
  useEffect(() => {
    const controls = animate(0, to, { duration: 1.2, ease: 'easeOut', onUpdate: (x) => setV(Math.round(x)) })
    return () => controls.stop()
  }, [to])
  return <>{v}</>
}

/* ---------- empty state ---------- */
export function EmptyState({ title, text, children }: { title: string; text: string; children?: ReactNode }) {
  return (
    <div className="card grid place-items-center gap-3 p-12 text-center">
      <p className="text-xl font-semibold">{title}</p>
      <p className="max-w-md text-sm text-white/55">{text}</p>
      {children}
    </div>
  )
}
```

---

## 4. Layout components (`src/components/`)

### `Backdrop.tsx`

```tsx
export default function Backdrop() {
  return (
    <>
      <div aria-hidden className="light-leak" />
      <div aria-hidden className="grid-lines" />
      <div aria-hidden className="vignette" />
      <div aria-hidden className="grain" />
    </>
  )
}
```

### `TopBar.tsx`

```tsx
import { Link } from 'react-router-dom'
import { useAuth } from '../lib/auth'
import { useProfile } from '../lib/profile'

export default function TopBar() {
  const { isOwner } = useAuth()
  const { profile } = useProfile()
  const name = profile.name || 'Portfolio'

  return (
    <header className="fixed inset-x-0 top-0 z-40 flex items-center justify-between px-5 py-4 md:px-8">
      <Link to="/" className="flex items-center gap-3" aria-label="Home">
        <span className="grid h-9 w-9 place-items-center rounded-full bg-white text-sm font-bold text-black">
          {name.trim().charAt(0).toUpperCase()}
        </span>
        <span className="hidden font-mono text-[11px] tracking-[0.3em] text-white/70 sm:block">
          {name.toUpperCase()}
        </span>
      </Link>
      <div className="flex items-center gap-2">
        {isOwner && <span className="chip">OWNER MODE</span>}
        <span className="chip flex items-center gap-2">
          <i className="h-1.5 w-1.5 animate-pulse rounded-full bg-white" />
          {profile.status || 'Online'}
        </span>
      </div>
    </header>
  )
}
```

### `AppShell.tsx` — pages, transitions, page-view tracking, bloom after the flash

```tsx
import { useEffect, useRef } from 'react'
import { Navigate, Route, Routes, useLocation } from 'react-router-dom'
import { AnimatePresence, motion } from 'motion/react'
import Backdrop from './Backdrop'
import TopBar from './TopBar'
import PortfolioDock from './PortfolioDock'
import SiteFooter from './SiteFooter'
import { api } from '../lib/api'
import { useAuth } from '../lib/auth'
import Dashboard from '../pages/Dashboard'
import Projects from '../pages/Projects'
import AiTools from '../pages/AiTools'
import Certificates from '../pages/Certificates'
import PhotoBooth from '../pages/PhotoBooth'
import Analytics from '../pages/Analytics'
import Skills from '../pages/Skills'
import Documentation from '../pages/Documentation'
import Profile from '../pages/Profile'
import Contact from '../pages/Contact'
import Settings from '../pages/Settings'

export default function AppShell() {
  const location = useLocation()
  const { isOwner } = useAuth()
  const last = useRef('')

  useEffect(() => {
    window.scrollTo({ top: 0 })
    // count a page view (the owner's own visits are not counted)
    if (isOwner || last.current === location.pathname) return
    last.current = location.pathname
    api('/track', { method: 'POST', body: JSON.stringify({ path: location.pathname }) }).catch(() => {})
  }, [location.pathname, isOwner])

  return (
    <div className="relative min-h-screen">
      <Backdrop />
      {/* light bloom that fades out right after the white flash */}
      <motion.div
        aria-hidden
        className="pointer-events-none fixed inset-0 z-[45] bg-white"
        initial={{ opacity: 0.85 }} animate={{ opacity: 0 }}
        transition={{ duration: 1.4, ease: 'easeOut' }}
      />
      <TopBar />

      <main className="relative z-10 mx-auto w-full max-w-6xl px-5 pt-24 md:px-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={location.pathname}
            initial={{ opacity: 0, y: 18, filter: 'blur(10px)' }}
            animate={{ opacity: 1, y: 0, filter: 'blur(0px)' }}
            exit={{ opacity: 0, y: -10, filter: 'blur(8px)' }}
            transition={{ duration: 0.4 }}
          >
            <Routes location={location}>
              <Route path="/" element={<Dashboard />} />
              <Route path="/projects" element={<Projects />} />
              <Route path="/ai-tools" element={<AiTools />} />
              <Route path="/certificates" element={<Certificates />} />
              <Route path="/photo-booth" element={<PhotoBooth />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/skills" element={<Skills />} />
              <Route path="/docs" element={<Documentation />} />
              <Route path="/profile" element={<Profile />} />
              <Route path="/contact" element={<Contact />} />
              <Route path="/settings" element={<Settings />} />
              <Route path="*" element={<Navigate to="/" replace />} />
            </Routes>
          </motion.div>
        </AnimatePresence>
      </main>

      <SiteFooter />
      <PortfolioDock />
    </div>
  )
}
```

### `PortfolioDock.tsx` — your menu in Dock style

On phones the Dock shows 4 pages + **More** (opens a sheet with every page). Right-click (or long-press) **My Projects** and **Contact** for small menus.

```tsx
import { useState, type ReactNode } from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { AnimatePresence, motion } from 'motion/react'
import { LogIn, LogOut, Menu, type LucideIcon } from 'lucide-react'
import { NAV, type NavItem } from '../lib/nav'
import { vendor } from '../lib/vendor'
import { useAuth } from '../lib/auth'
import { useProfile } from '../lib/profile'
import { useIsMobile } from '../lib/useIsMobile'

type DockItem =
  | { icon: ReactNode; label: string; onClick?: () => void; active?: boolean; menu?: unknown[] }
  | { separator: true }

const glyph = (Icon: LucideIcon) => <Icon size="1em" strokeWidth={1.6} />

/* simple Dock used until you add src/vendor/Dock.jsx */
function FallbackDock({ items }: { items: DockItem[] }) {
  return (
    <nav className="pointer-events-auto absolute bottom-5 left-1/2 flex -translate-x-1/2 items-center gap-2 rounded-full border border-white/15 bg-black/70 px-3 py-2 backdrop-blur-xl">
      {items.map((it, i) =>
        'separator' in it ? (
          <span key={i} className="mx-1 h-6 w-px bg-white/20" />
        ) : (
          <button
            key={it.label} title={it.label} aria-label={it.label} onClick={it.onClick}
            className={`grid h-11 w-11 place-items-center rounded-full text-xl transition hover:scale-125 ${
              it.active ? 'bg-white text-black' : 'text-white/80 hover:bg-white/10'
            }`}
          >
            {it.icon}
          </button>
        )
      )}
    </nav>
  )
}

export default function PortfolioDock() {
  const navigate = useNavigate()
  const { pathname } = useLocation()
  const { isOwner, logout } = useAuth()
  const { profile } = useProfile()
  const mobile = useIsMobile()
  const [sheet, setSheet] = useState(false)
  const Dock = vendor('Dock')

  const go = (path: string) => () => {
    setSheet(false)
    navigate(path)
  }
  const authAction = () => {
    setSheet(false)
    if (isOwner) {
      logout()
      navigate('/')
    } else {
      navigate('/settings')
    }
  }
  const navItem = (n: NavItem): DockItem => ({ icon: glyph(n.icon), label: n.label, active: pathname === n.path, onClick: go(n.path) })

  const withMenu = (n: NavItem): DockItem => {
    const base = navItem(n) as Exclude<DockItem, { separator: true }>
    if (n.id === 'projects') {
      return { ...base, menu: [{ label: 'Open projects', onClick: go('/projects') }] }
    }
    if (n.id === 'contact' && profile.email) {
      return {
        ...base,
        menu: [
          { label: 'Send email', onClick: () => (window.location.href = `mailto:${profile.email}`) },
          { label: 'Copy email', onClick: () => navigator.clipboard?.writeText(profile.email) }
        ]
      }
    }
    return base
  }

  const desktopItems: DockItem[] = [
    ...NAV.slice(0, 10).map(withMenu),
    { separator: true },
    navItem(NAV[10]), // Settings
    { icon: glyph(isOwner ? LogOut : LogIn), label: isOwner ? 'Logout' : 'Login', onClick: authAction }
  ]
  const mobileItems: DockItem[] = [
    ...[NAV[0], NAV[1], NAV[2], NAV[8]].map(navItem),
    { icon: glyph(Menu), label: 'More', onClick: () => setSheet(true) }
  ]
  const items = mobile ? mobileItems : desktopItems
  const size = mobile
    ? { baseItemSize: 44, magnification: 56, panelHeight: 60, distance: 120, gap: 8 }
    : { baseItemSize: 50, magnification: 70, panelHeight: 68, distance: 200, gap: 10 }

  return (
    <>
      <div style={{ position: 'fixed', inset: 0, pointerEvents: 'none', zIndex: 50 }}>
        {Dock ? (
          <Dock
            items={items} position="bottom" roundness={0.5}
            accentColor="#ffffff" badgeColor="#ffffff" theme="dark"
            bounce autoHide={false} tiles showLabels showIndicators showBadges
            style={{ pointerEvents: 'auto' }}
            {...size}
          />
        ) : (
          <FallbackDock items={items} />
        )}
      </div>

      {/* phone menu sheet */}
      <AnimatePresence>
        {sheet && (
          <motion.div
            className="fixed inset-0 z-[60] flex items-end bg-black/70 backdrop-blur-sm"
            initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}
            onClick={() => setSheet(false)}
          >
            <motion.div
              className="panel grid w-full grid-cols-3 gap-3 rounded-b-none p-5 pb-8"
              initial={{ y: 80 }} animate={{ y: 0 }} exit={{ y: 80 }}
              onClick={(e) => e.stopPropagation()}
            >
              {NAV.map((n) => (
                <button key={n.id} onClick={go(n.path)} className="card grid place-items-center gap-2 p-4 text-xs">
                  <n.icon size={20} strokeWidth={1.6} /> {n.label}
                </button>
              ))}
              <button onClick={authAction} className="card grid place-items-center gap-2 p-4 text-xs">
                {isOwner ? <LogOut size={20} /> : <LogIn size={20} />} {isOwner ? 'Logout' : 'Login'}
              </button>
            </motion.div>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  )
}
```

### `SiteFooter.tsx` — placeholder for now

The real end-of-page effect comes in `15-footer-techtext-effect.md`. Create this small version now so the app compiles:

```tsx
export default function SiteFooter() {
  return <footer className="relative z-10 h-40" />
}
```

---

## 5. Check

1. `npm run dev` will show errors until the page files exist. Create the next md files, or make empty temporary pages (`export default function X() { return null }`).
2. After the backend (`14-backend-server.md`) is running, the top bar shows your name and the Dock appears at the bottom.
3. Dock icons grow when the mouse comes near. On a phone you see 4 icons + **More**.
