# 05 · Menu 3 — AI Tools

A beginner developer guide to AI tools: **ChatGPT, Gemini, Claude, Ollama, GitHub Copilot, Perplexity**.

- Big **rounded** cards with a **light that follows your mouse** and a soft **3D tilt**
- Each card: what it is good for, a starter prompt (copy button), and a link
- A beginner roadmap (4 steps)
- A "run AI on your own Mac with Ollama" terminal box with copy buttons

**Route:** `/ai-tools` · No backend needed (static content). Tool names, links and tips are plain text in the `TOOLS` array, so you can edit them.

> Free limits and prices change often. The page says "check the website for current limits" instead of showing numbers that can become wrong.

---

## `src/pages/AiTools.tsx`

```tsx
import { useState } from 'react'
import { ArrowUpRight, Asterisk, Check, Code2, Copy, MessagesSquare, Search, Server, Sparkles, type LucideIcon } from 'lucide-react'
import { PageHeader, SpotlightCard } from '../components/ui'

type Tool = {
  name: string; maker: string; icon: LucideIcon; tagline: string
  bestFor: string[]; starter: string; url: string
}

const TOOLS: Tool[] = [
  {
    name: 'ChatGPT', maker: 'OpenAI', icon: MessagesSquare,
    tagline: 'All-round assistant for learning, writing and debugging.',
    bestFor: ['Explaining code step by step', 'Brainstorming project ideas', 'Writing README files'],
    starter: 'Explain this Python error like I am a beginner, then show the fixed code: <paste error>',
    url: 'https://chatgpt.com'
  },
  {
    name: 'Gemini', maker: 'Google', icon: Sparkles,
    tagline: 'Google\'s assistant, strong when you already live in Google apps.',
    bestFor: ['Summaries of long text', 'Working with Docs and Gmail', 'Quick explanations'],
    starter: 'Make a 7-day study plan to learn React from zero. One small project each day.',
    url: 'https://gemini.google.com'
  },
  {
    name: 'Claude', maker: 'Anthropic', icon: Asterisk,
    tagline: 'Careful writing and long documents; good for reading and reviewing code.',
    bestFor: ['Reviewing my code for mistakes', 'Reading long documents', 'Clear technical writing'],
    starter: 'Review this React component. List bugs first, then improvements, then the cleaned code.',
    url: 'https://claude.ai'
  },
  {
    name: 'Ollama', maker: 'Open source', icon: Server,
    tagline: 'Run open AI models on your own computer — offline and private.',
    bestFor: ['Learning how LLMs run locally', 'Private experiments', 'No account needed'],
    starter: 'ollama run llama3.2',
    url: 'https://ollama.com'
  },
  {
    name: 'GitHub Copilot', maker: 'GitHub', icon: Code2,
    tagline: 'Suggests code while you type, right inside VS Code.',
    bestFor: ['Auto-complete for code', 'Writing tests', 'Explaining selected code'],
    starter: '// write a function that counts the most used words in a chat log',
    url: 'https://github.com/features/copilot'
  },
  {
    name: 'Perplexity', maker: 'Perplexity', icon: Search,
    tagline: 'Search-style answers that show their sources.',
    bestFor: ['Researching a new library', 'Comparing technologies', 'Finding sources to verify'],
    starter: 'Compare Vite and Next.js for a student portfolio. Show sources.',
    url: 'https://www.perplexity.ai'
  }
]

const STEPS = [
  ['01', 'Ask clearly', 'Say what you want, in what language, and what you already tried.'],
  ['02', 'Give context', 'Paste the error message or the code. More context = better answer.'],
  ['03', 'Verify', 'Run the code. Read the docs. AI can be confidently wrong.'],
  ['04', 'Iterate', 'Reply with what failed. Improve step by step instead of starting over.']
]

const OLLAMA = ['brew install ollama', 'ollama run llama3.2', 'ollama list']

function CopyButton({ text, label = 'Copy' }: { text: string; label?: string }) {
  const [done, setDone] = useState(false)
  return (
    <button
      className="btn !px-3 !py-1.5 !text-xs"
      onClick={async () => {
        await navigator.clipboard?.writeText(text)
        setDone(true)
        setTimeout(() => setDone(false), 1500)
      }}
    >
      {done ? <Check size={13} /> : <Copy size={13} />} {done ? 'Copied' : label}
    </button>
  )
}

export default function AiTools() {
  return (
    <div>
      <PageHeader
        index="03 / AI TOOLS"
        title="AI Tools"
        sub="The AI tools I use to learn faster as a beginner developer. Move your mouse over a card."
      />

      <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
        {TOOLS.map((t) => (
          <SpotlightCard key={t.name} tilt={7} className="flex flex-col rounded-[2rem] p-7">
            <div className="flex items-center justify-between">
              <span className="grid h-14 w-14 place-items-center rounded-full border border-white/20 bg-white/5">
                <t.icon size={24} strokeWidth={1.5} />
              </span>
              <span className="chip">{t.maker}</span>
            </div>
            <h3 className="mt-6 text-2xl font-semibold tracking-tight">{t.name}</h3>
            <p className="mt-2 text-sm leading-relaxed text-white/60">{t.tagline}</p>

            <ul className="mt-5 space-y-1.5 text-sm text-white/75">
              {t.bestFor.map((b) => (
                <li key={b} className="flex gap-2"><span className="text-white/35">▸</span>{b}</li>
              ))}
            </ul>

            <div className="mt-5 rounded-2xl border border-white/10 bg-black/40 p-3 font-mono text-[11.5px] leading-5 text-white/60">
              {t.starter}
            </div>

            <div className="mt-auto flex items-center gap-2 pt-5">
              <CopyButton text={t.starter} label="Copy prompt" />
              <a className="btn btn-solid !px-3 !py-1.5 !text-xs" href={t.url} target="_blank" rel="noreferrer">
                Open <ArrowUpRight size={13} />
              </a>
            </div>
          </SpotlightCard>
        ))}
      </div>

      <section className="mt-16">
        <p className="font-mono text-[11px] tracking-[0.3em] text-white/40">BEGINNER ROADMAP</p>
        <h2 className="mt-2 text-3xl font-semibold tracking-tight">How to use AI without getting lost</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {STEPS.map(([n, title, text]) => (
            <SpotlightCard key={n} className="rounded-[1.75rem] p-6">
              <p className="font-mono text-xs text-white/40">{n}</p>
              <p className="mt-4 text-lg font-semibold">{title}</p>
              <p className="mt-2 text-sm text-white/60">{text}</p>
            </SpotlightCard>
          ))}
        </div>
        <p className="mt-4 text-sm text-white/50">
          Never paste passwords, API keys or private data into any AI chat.
        </p>
      </section>

      <section className="mt-16">
        <p className="font-mono text-[11px] tracking-[0.3em] text-white/40">LOCAL AI</p>
        <h2 className="mt-2 text-3xl font-semibold tracking-tight">Run AI on your own Mac with Ollama</h2>
        <div className="panel mt-6 space-y-3 p-5 font-mono text-sm">
          {OLLAMA.map((cmd) => (
            <div key={cmd} className="flex items-center justify-between gap-3">
              <span><span className="text-white/40">$ </span>{cmd}</span>
              <CopyButton text={cmd} />
            </div>
          ))}
        </div>
        <p className="mt-3 text-sm text-white/50">
          Pick any model from ollama.com/library. Small models run on most laptops; check each model page for its size.
        </p>
      </section>
    </div>
  )
}
```

---

## Notes

- Icons are simple symbols (lucide). Official brand logos are trademarked, so I did not copy them. If you want real logos, download them from each company's brand page and put them in `public/logos/`, then replace `<t.icon />` with `<img src="/logos/chatgpt.svg" />`.
- To add another tool, copy one object in `TOOLS`. The grid adjusts automatically.
- The `!px-3` style (with `!`) is a Tailwind "important" override to make the small buttons.
