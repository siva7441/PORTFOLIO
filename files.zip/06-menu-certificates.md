# 06 · Menu 4 — Certificates (all your courses)

A 3D **drifting wall** of your course certificates (your `DriftWall` component), plus a grid below with title, issuer and date.

**You can upload many certificates at once:** login → **Add certificates** → select many images. Each upload creates a certificate card. You can edit the title, issuer, date and verification link on the card, or delete it.

**Route:** `/certificates` · **Vendor file:** `src/vendor/DriftWall.jsx` + `DriftWall.css` (from `portfolio_driftwall_setup.md`; fallback grid included).

**Tip for files:** export PDF certificates as `.jpg` or `.png` first (landscape). Images are resized automatically before upload.

---

## `src/pages/Certificates.tsx`

```tsx
import { useState } from 'react'
import { ExternalLink, Trash2 } from 'lucide-react'
import { EmptyState, Modal, PageHeader, UploadButton } from '../components/ui'
import { OwnerOnly } from '../lib/auth'
import { useCollection } from '../lib/useCollection'
import { vendor } from '../lib/vendor'
import type { Certificate } from '../lib/types'

export default function Certificates() {
  const { items, loading, add, update, remove } = useCollection<Certificate>('certificates')
  const DriftWall = vendor('DriftWall')
  const [open, setOpen] = useState<Certificate | null>(null)

  const wallItems = items.map((c) => ({ image: c.image, title: c.title, href: c.href || undefined }))
  const columns = Math.min(5, Math.max(2, Math.ceil(items.length / 2)))

  return (
    <div>
      <PageHeader
        index="04 / CERTIFICATES"
        title="Certificates"
        sub="Courses I completed. Move the mouse over the wall to focus a certificate."
      >
        <OwnerOnly>
          <UploadButton
            kind="certificate" multiple label="Add certificates" className="btn btn-solid"
            onUploaded={(url, file) =>
              add({
                title: file.name.replace(/\.[^.]+$/, '').replace(/[-_]+/g, ' '),
                issuer: '', date: '', image: url, href: ''
              })
            }
          />
        </OwnerOnly>
      </PageHeader>

      {!loading && items.length === 0 && (
        <EmptyState
          title="No certificates yet"
          text="Login in Settings, then press Add certificates and choose all your course images."
        />
      )}

      {items.length > 0 && (
        <div className="relative -mx-5 h-[520px] md:mx-0 md:h-[600px]">
          {DriftWall ? (
            <DriftWall
              items={wallItems} columns={columns} tileWidth={220} tileHeight={150} gap={18}
              tilt={16} turn={-14} perspective={1200} depth={120} speed={35} direction="up"
              variance={0.45} parallax={0.6} lift={64} fade={0.6} dim={0.65}
              overlayColor="#000000" radius={14} roll={0} pauseOnHover grayscale
            />
          ) : (
            <div className="grid h-full grid-cols-2 gap-3 overflow-hidden p-4 md:grid-cols-4">
              {items.map((c) => (
                <img key={c.id} src={c.image} alt={c.title} className="aspect-[3/2] w-full rounded-xl object-cover opacity-70" />
              ))}
            </div>
          )}
        </div>
      )}

      {items.length > 0 && (
        <section className="mt-12">
          <p className="font-mono text-[11px] tracking-[0.3em] text-white/40">ALL COURSES · {items.length}</p>
          <div className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            {items.map((c) => (
              <article key={c.id} className="card overflow-hidden">
                <button className="block w-full" onClick={() => setOpen(c)} aria-label={`Open ${c.title}`}>
                  <img src={c.image} alt={c.title} loading="lazy" className="aspect-[3/2] w-full object-cover grayscale transition duration-500 hover:grayscale-0" />
                </button>
                <div className="space-y-2 p-4">
                  <OwnerOnly>
                    <input className="input" defaultValue={c.title} placeholder="Course title"
                      onBlur={(e) => e.target.value !== c.title && update(c.id, { title: e.target.value })} />
                    <input className="input" defaultValue={c.issuer} placeholder="Issued by (Coursera, NPTEL…)"
                      onBlur={(e) => e.target.value !== c.issuer && update(c.id, { issuer: e.target.value })} />
                    <div className="flex gap-2">
                      <input className="input" defaultValue={c.date} placeholder="Date (2026-03)"
                        onBlur={(e) => e.target.value !== c.date && update(c.id, { date: e.target.value })} />
                      <input className="input" defaultValue={c.href} placeholder="Verify link https://"
                        onBlur={(e) => e.target.value !== c.href && update(c.id, { href: e.target.value })} />
                    </div>
                    <button className="btn !px-3 !py-1.5 !text-xs" onClick={() => confirm(`Delete "${c.title}"?`) && remove(c.id)}>
                      <Trash2 size={13} /> Delete
                    </button>
                  </OwnerOnly>
                  {/* visitors see this */}
                  <div className="owner-hide">
                    <p className="font-medium">{c.title}</p>
                    <p className="text-xs text-white/50">{[c.issuer, c.date].filter(Boolean).join(' · ')}</p>
                    {c.href && (
                      <a className="mt-2 inline-flex items-center gap-1 text-xs underline underline-offset-4" href={c.href} target="_blank" rel="noreferrer">
                        Verify <ExternalLink size={12} />
                      </a>
                    )}
                  </div>
                </div>
              </article>
            ))}
          </div>
        </section>
      )}

      <Modal open={!!open} onClose={() => setOpen(null)} title={open?.title ?? ''} wide>
        {open && <img src={open.image} alt={open.title} className="w-full rounded-xl" />}
      </Modal>
    </div>
  )
}
```

### One small CSS line

The `owner-hide` block (text for visitors) should be hidden when the owner is editing. Add this at the end of `src/index.css`:

```css
/* when the owner edit fields are visible, hide the read-only text next to them */
.card:has(input) .owner-hide { display: none; }
```

---

## Notes

- Add as many certificates as you complete. The wall spreads them across columns automatically (2 to 5 columns).
- A certificate with a **Verify link** opens that link when you click it on the wall.
- Click a thumbnail in the grid to see the full certificate.
- If the wall looks empty with 1–2 images, that is normal. It looks best with 8 or more.
