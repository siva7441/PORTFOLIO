# 03 · Menu 1 — Dashboard

The home page after the intro. It shows:

- Greeting with your name (Good morning / afternoon / evening)
- A **terminal** that types your real data (`whoami`, projects, focus)
- 4 counters: Projects, Certificates, Photos, Page views (they count up)
- Featured project and your latest certificates
- Owner quick buttons (visible only after login)

**Route:** `/` · **Needs:** `02-foundation-layout-dock.md` and the backend `14-backend-server.md`.

---

## 1. `src/components/Terminal.tsx`

A black terminal window that types line by line. Lines starting with `$` are commands.

```tsx
import { useEffect, useState } from 'react'

export default function Terminal({ lines }: { lines: string[] }) {
  const [shown, setShown] = useState(0) // finished lines
  const [chars, setChars] = useState(0) // letters typed in the current line

  useEffect(() => {
    if (shown >= lines.length) return
    const line = lines[shown]
    if (chars < line.length) {
      const t = setTimeout(() => setChars((c) => c + 1), line.startsWith('$') ? 55 : 14)
      return () => clearTimeout(t)
    }
    const t = setTimeout(() => {
      setShown((s) => s + 1)
      setChars(0)
    }, 380)
    return () => clearTimeout(t)
  }, [shown, chars, lines])

  return (
    <div className="panel overflow-hidden font-mono text-[12.5px] leading-6">
      <div className="flex items-center gap-2 border-b border-white/10 px-4 py-3">
        <i className="h-2.5 w-2.5 rounded-full border border-white/40" />
        <i className="h-2.5 w-2.5 rounded-full border border-white/40" />
        <i className="h-2.5 w-2.5 rounded-full border border-white/40" />
        <span className="ml-3 text-[10px] tracking-[0.25em] text-white/40">TERMINAL</span>
      </div>
      <div className="min-h-[220px] p-4">
        {lines.slice(0, shown).map((l, i) => (
          <p key={i} className={l.startsWith('$') ? 'text-white' : 'text-white/55'}>
            {l}
          </p>
        ))}
        {shown < lines.length && (
          <p className={lines[shown].startsWith('$') ? 'text-white' : 'text-white/55'}>
            {lines[shown].slice(0, chars)}
            <span className="ml-0.5 inline-block h-4 w-2 translate-y-0.5 animate-pulse bg-white" />
          </p>
        )}
        {shown >= lines.length && (
          <p className="text-white">
            $ <span className="inline-block h-4 w-2 translate-y-0.5 animate-pulse bg-white" />
          </p>
        )}
      </div>
    </div>
  )
}
```

---

## 2. `src/pages/Dashboard.tsx`

```tsx
import { useMemo } from 'react'
import { Link } from 'react-router-dom'
import { motion } from 'motion/react'
import { ArrowUpRight, Award, Camera, Eye, FolderKanban, Plus } from 'lucide-react'
import { Count, PageHeader, SpotlightCard } from '../components/ui'
import Terminal from '../components/Terminal'
import { OwnerOnly } from '../lib/auth'
import { useProfile } from '../lib/profile'
import { useCollection } from '../lib/useCollection'
import { useApi } from '../lib/useApi'
import type { Certificate, Photo, Project, Skill } from '../lib/types'

export default function Dashboard() {
  const { profile } = useProfile()
  const projects = useCollection<Project>('projects')
  const certs = useCollection<Certificate>('certificates')
  const photos = useCollection<Photo>('photos')
  const skills = useCollection<Skill>('skills')
  const stats = useApi<{ totalViews: number }>('/analytics')

  const hour = new Date().getHours()
  const greet = hour < 12 ? 'Good morning' : hour < 18 ? 'Good afternoon' : 'Good evening'
  const ready = !!profile.name && !projects.loading && !skills.loading

  const lines = useMemo(() => {
    const top = [...skills.items].sort((a, b) => b.level - a.level).slice(0, 3).map((s) => s.name)
    return [
      '$ whoami',
      `${profile.name} — ${profile.title}`,
      '$ ls projects/',
      projects.items.map((p) => p.title).join('   ') || '(no projects yet)',
      '$ skills --top 3',
      top.join(' · ') || '(add skills)',
      '$ status',
      profile.status || 'online'
    ]
  }, [profile, projects.items, skills.items])

  const cards = [
    { label: 'Projects', value: projects.items.length, icon: FolderKanban, to: '/projects' },
    { label: 'Certificates', value: certs.items.length, icon: Award, to: '/certificates' },
    { label: 'Photos', value: photos.items.length, icon: Camera, to: '/photo-booth' },
    { label: 'Page views', value: stats?.totalViews ?? 0, icon: Eye, to: '/analytics' }
  ]
  const featured = projects.items[0]
  const latestCerts = certs.items.slice(-3).reverse()

  return (
    <div className="space-y-6 pb-4">
      <PageHeader index="01 / DASHBOARD" title={`${greet}.`} sub={profile.bio} />

      <div className="grid gap-6 lg:grid-cols-[1.1fr_1fr]">
        <div className="flex flex-col justify-between gap-6">
          <div>
            <p className="text-sm text-white/50">{profile.title}</p>
            <p className="mt-1 text-3xl font-semibold tracking-tight md:text-4xl">{profile.name}</p>
            <div className="mt-6 flex flex-wrap gap-2">
              <Link to="/projects" className="btn btn-solid">View projects <ArrowUpRight size={16} /></Link>
              <Link to="/contact" className="btn">Contact me</Link>
            </div>
          </div>
          <OwnerOnly>
            <div className="flex flex-wrap gap-2">
              <Link to="/projects" className="btn"><Plus size={16} /> Add project</Link>
              <Link to="/certificates" className="btn"><Plus size={16} /> Add certificates</Link>
              <Link to="/photo-booth" className="btn"><Plus size={16} /> Add photos</Link>
            </div>
          </OwnerOnly>
        </div>
        {ready ? <Terminal lines={lines} /> : <div className="panel min-h-[260px]" />}
      </div>

      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        {cards.map((c, i) => (
          <motion.div key={c.label} initial={{ opacity: 0, y: 16 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 * i }}>
            <Link to={c.to}>
              <SpotlightCard className="p-5">
                <c.icon size={18} className="text-white/60" />
                <p className="mt-5 text-4xl font-semibold tracking-tight"><Count to={c.value} /></p>
                <p className="mt-1 text-xs text-white/50">{c.label}</p>
              </SpotlightCard>
            </Link>
          </motion.div>
        ))}
      </div>

      <div className="grid gap-4 lg:grid-cols-2">
        <SpotlightCard className="p-6">
          <p className="font-mono text-[11px] tracking-[0.25em] text-white/40">FEATURED PROJECT</p>
          {featured ? (
            <>
              <h3 className="mt-3 text-2xl font-semibold">{featured.title}</h3>
              <p className="text-sm text-white/50">{featured.subtitle}</p>
              <p className="mt-3 text-sm leading-relaxed text-white/70">{featured.description}</p>
              <div className="mt-4 flex flex-wrap gap-2">
                {featured.highlights.map((h) => <span key={h} className="chip">{h}</span>)}
              </div>
              <Link to="/projects" className="mt-5 inline-flex items-center gap-1 text-sm underline underline-offset-4">
                Open all projects <ArrowUpRight size={14} />
              </Link>
            </>
          ) : (
            <p className="mt-3 text-sm text-white/50">No project yet. Login and add your first project.</p>
          )}
        </SpotlightCard>

        <SpotlightCard className="p-6">
          <p className="font-mono text-[11px] tracking-[0.25em] text-white/40">LATEST CERTIFICATES</p>
          {latestCerts.length ? (
            <div className="mt-4 grid grid-cols-3 gap-3">
              {latestCerts.map((c) => (
                <Link to="/certificates" key={c.id} className="block">
                  <img src={c.image} alt={c.title} className="aspect-[3/2] w-full rounded-xl border border-white/10 object-cover grayscale transition hover:grayscale-0" />
                  <p className="mt-2 line-clamp-2 text-xs text-white/60">{c.title}</p>
                </Link>
              ))}
            </div>
          ) : (
            <p className="mt-3 text-sm text-white/50">Your completed courses will appear here after you upload certificates.</p>
          )}
        </SpotlightCard>
      </div>
    </div>
  )
}
```

---

## 3. Test

1. Dock → **Dashboard**: the terminal types `whoami`, your projects and top skills.
2. Numbers count up. **Page views** grows when other people (not you as owner) open pages.
3. After owner login you see the **Add project / certificates / photos** shortcuts.
4. All text comes from your data. Change it in **Profile** and **My Projects**.
